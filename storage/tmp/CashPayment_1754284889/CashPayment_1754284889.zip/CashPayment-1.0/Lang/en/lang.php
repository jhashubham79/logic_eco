<?php
return [
    'title'      => 'Cash payment',
    'admin'      => [
        'title'          => 'Cash payment',
    ],
];
