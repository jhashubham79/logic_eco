<?php
return [
    'title'      => 'Thanh toán tiền mặt',
    'admin'      => [
        'title'          => 'Thanh toán tiền mặt',
    ],
];
