# CashPayment Plugin

## English

### Description
This is a basic Payment plugin for GP247/Shop, designed to handle cash payments where orders are created successfully but payment is handled offline between the buyer and seller.

### Features
- Create orders with cash payment method
- No online payment processing required
- Orders are marked as pending payment
- Flexible configuration through config.php file

### Requirements
- GP247/Shop must be pre-installed in the system

### Installation
There are 3 ways to install the plugin:

1. **Online Installation**
   - Access the Plugin library
   - Find and install the CashPayment plugin

2. **ZIP File Installation**
   - Import the plugin zip file
   - System will automatically install the plugin

3. **Manual Installation**
   - Extract the plugin file
   - Copy all contents to `app/GP247/Plugins/CashPayment` directory
   - Access the admin page
   - Go to `Save local` to complete installation

---

## Tiếng Việt

### Mô tả
Đây là Plugin Payment cơ bản dành cho GP247/Shop, được thiết kế để xử lý thanh toán tiền mặt, nơi đơn hàng được tạo thành công nhưng việc thanh toán được thực hiện ngoại tuyến giữa người mua và người bán.

### Tính năng
- Tạo đơn hàng với phương thức thanh toán tiền mặt
- Không yêu cầu xử lý thanh toán trực tuyến
- Đơn hàng được đánh dấu là chờ thanh toán
- Cấu hình linh hoạt thông qua file config.php

### Yêu cầu
- GP247/Shop đã được cài đặt sẵn trong hệ thống

### Cách cài đặt
Có 3 cách để cài đặt plugin:

1. **Cài đặt online**
   - Truy cập thư viện Plugin
   - Tìm và cài đặt CashPayment plugin

2. **Cài đặt qua file zip**
   - Import file zip chứa plugin
   - Hệ thống sẽ tự động cài đặt

3. **Cài đặt thủ công**
   - Giải nén file plugin
   - Copy toàn bộ nội dung vào thư mục `app/GP247/Plugins/CashPayment`
   - Truy cập trang admin
   - Vào mục `Save local` để hoàn tất cài đặt