<?php
return [
    'title'      => 'Thanh toán Paypal Express',
    'admin'      => [
        'title'          => 'Thanh toán Paypal Express',
    ],
    'order_status_success' => 'Đơn hàng đã được xử lý',
    'payment_status_success' => 'Đơn hàng đã được thanh toán',
    'order_status_refunded' => 'Đơn hàng đã được hoàn trả',
    'payment_status_refunded' => 'Thanh toán đã được hoàn trả',
    'config_paypal' => 'Cấu hình Paypal Express',
];
