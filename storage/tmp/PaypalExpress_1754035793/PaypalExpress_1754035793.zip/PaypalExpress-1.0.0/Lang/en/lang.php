<?php
return [
    'title'      => 'Paypal Express',
    'admin'      => [
        'title'     => 'Paypal Express',
    ],
    'order_status_success' => 'Order status success',
    'payment_status_success' => 'Payment status success',
    'order_status_refunded' => 'Order status refunded',
    'payment_status_refunded' => 'Payment status refunded',
    'config_paypal' => 'Paypal Express Config',
];
